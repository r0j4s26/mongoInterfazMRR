const mongoose = require('mongoose');
const HistorialDePagoService = require('../services/historialDePagoService');

const VALID_INCLUDES = {
  cliente: { path: 'clienteId' }
};

function buildPopulate(includeParam) {
  if (!includeParam) return undefined;
  const parts = String(includeParam).split(',').map(s => s.trim()).filter(Boolean);
  const populate = parts.map(p => VALID_INCLUDES[p]).filter(Boolean);
  return populate.length ? populate : undefined;
}

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /historialdepago
async function getAll(req, res) {
  try {
    const { include, page = 1, limit = 50, clienteId, metodoPago } = req.query;

    const filter = {};
    if (clienteId && isValidObjectId(clienteId)) filter.clienteId = clienteId;
    if (metodoPago) filter.metodoPago = metodoPago;

    const options = {
      populate: buildPopulate(include),
      sort: { fechaPago: -1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await HistorialDePagoService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /historialdepago/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await HistorialDePagoService.findById(id, { populate: buildPopulate(req.query.include) });
    if (!doc) return res.status(404).json({ message: 'Registro no encontrado' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /historialdepago
async function create(req, res) {
  try {
    const doc = await HistorialDePagoService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /historialdepago/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await HistorialDePagoService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Registro no encontrado' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /historialdepago/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await HistorialDePagoService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Registro no encontrado' });
    res.json({ message: 'Registro eliminado correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove };
