const mongoose = require('mongoose');
const ComprasService = require('../services/comprasService');

const VALID_INCLUDES = {
  proveedor: { path: 'proveedorId' }
};

function buildPopulate(includeParam) {
  if (!includeParam) return undefined;
  const parts = String(includeParam).split(',').map(s => s.trim()).filter(Boolean);
  const populate = parts.map(p => VALID_INCLUDES[p]).filter(Boolean);
  return populate.length ? populate : undefined;
}

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /compras
async function getAll(req, res) {
  try {
    const { include, page = 1, limit = 50, estado, proveedorId } = req.query;

    const filter = {};
    if (estado) filter.estado = estado;
    if (proveedorId && isValidObjectId(proveedorId)) filter.proveedorId = proveedorId;

    const options = {
      populate: buildPopulate(include),
      sort: { fechaCompra: -1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await ComprasService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /compras/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await ComprasService.findById(id, { populate: buildPopulate(req.query.include) });
    if (!doc) return res.status(404).json({ message: 'Compra no encontrada' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /compras
async function create(req, res) {
  try {
    const doc = await ComprasService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /compras/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await ComprasService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Compra no encontrada' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /compras/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await ComprasService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Compra no encontrada' });
    res.json({ message: 'Compra eliminada correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove };
