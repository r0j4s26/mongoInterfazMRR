const mongoose = require('mongoose');
const EncargosService = require('../services/encargosService');

const VALID_INCLUDES = {
  cliente: { path: 'clienteId' }
};

function buildPopulate(includeParam) {
  if (!includeParam) return undefined;
  const parts = String(includeParam).split(',').map(s => s.trim()).filter(Boolean);
  const populate = parts.map(p => VALID_INCLUDES[p]).filter(Boolean);
  return populate.length ? populate : undefined;
}

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /encargos
async function getAll(req, res) {
  try {
    const { include, page = 1, limit = 50, estado, clienteId } = req.query;

    const filter = {};
    if (estado) filter.estado = estado;
    if (clienteId && isValidObjectId(clienteId)) filter.clienteId = clienteId;

    const options = {
      populate: buildPopulate(include),
      sort: { fechaEncargo: -1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await EncargosService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /encargos/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await EncargosService.findById(id, { populate: buildPopulate(req.query.include) });
    if (!doc) return res.status(404).json({ message: 'Encargo no encontrado' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /encargos
async function create(req, res) {
  try {
    const doc = await EncargosService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /encargos/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await EncargosService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Encargo no encontrado' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /encargos/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await EncargosService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Encargo no encontrado' });
    res.json({ message: 'Encargo eliminado correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove };
