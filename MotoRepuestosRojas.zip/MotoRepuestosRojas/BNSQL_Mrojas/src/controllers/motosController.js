const mongoose = require('mongoose');
const MotosService = require('../services/motosService');

const VALID_INCLUDES = {
  cliente: { path: 'clienteId' }
};

function buildPopulate(includeParam) {
  if (!includeParam) return undefined;
  const parts = String(includeParam).split(',').map(s => s.trim()).filter(Boolean);
  const populate = parts.map(p => VALID_INCLUDES[p]).filter(Boolean);
  return populate.length ? populate : undefined;
}

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /motos
async function getAll(req, res) {
  try {
    const { include, page = 1, limit = 50, clienteId, marca, modelo, placa } = req.query;

    const filter = {};
    if (clienteId && isValidObjectId(clienteId)) filter.clienteId = clienteId;
    if (marca) filter.marca = { $regex: marca, $options: 'i' };
    if (modelo) filter.modelo = { $regex: modelo, $options: 'i' };
    if (placa) filter.placa = Number(placa);

    const options = {
      populate: buildPopulate(include),
      sort: { marca: 1, modelo: 1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await MotosService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /motos/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await MotosService.findById(id, { populate: buildPopulate(req.query.include) });
    if (!doc) return res.status(404).json({ message: 'Moto no encontrada' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /motos
async function create(req, res) {
  try {
    const doc = await MotosService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /motos/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await MotosService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Moto no encontrada' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /motos/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await MotosService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Moto no encontrada' });
    res.json({ message: 'Moto eliminada correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove };
