const ProveedoresService = require('../services/proveedoresService');

// GET /proveedores
async function getProveedores(req, res) {
  try {
    const proveedores = await ProveedoresService.getProveedores();
    res.json(proveedores);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// GET /proveedores/:id
async function getProveedor(req, res) {
  try {
    const proveedor = await ProveedoresService.getProveedor(req.params.id);
    if (!proveedor) return res.status(404).json({ message: 'Proveedor no encontrado' });
    res.json(proveedor);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// POST /proveedores
async function createProveedor(req, res) {
  try {
    const newProveedor = await ProveedoresService.createProveedor(req.body);
    res.status(201).json(newProveedor);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// PUT /proveedores/:id
async function updateProveedor(req, res) {
  try {
    const updatedProveedor = await ProveedoresService.updateProveedor(req.params.id, req.body);
    if (!updatedProveedor) return res.status(404).json({ message: 'Proveedor no encontrado' });
    res.json(updatedProveedor);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

// DELETE /proveedores/:id
async function deleteProveedor(req, res) {
  try {
    const deletedProveedor = await ProveedoresService.deleteProveedor(req.params.id);
    if (!deletedProveedor) return res.status(404).json({ message: 'Proveedor no encontrado' });
    res.json({ message: 'Proveedor eliminado correctamente' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
}

module.exports = { getProveedores, getProveedor, createProveedor, updateProveedor, deleteProveedor };
