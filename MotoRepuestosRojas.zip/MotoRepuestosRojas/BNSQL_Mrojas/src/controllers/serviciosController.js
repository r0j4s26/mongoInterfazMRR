const mongoose = require('mongoose');
const ServiciosService = require('../services/serviciosService');

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /servicios
async function getAll(req, res) {
  try {
    const { page = 1, limit = 50, nombre } = req.query;

    const filter = {};
    if (nombre) filter.nombre = { $regex: nombre, $options: 'i' };

    const options = {
      sort: { nombre: 1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await ServiciosService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /servicios/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await ServiciosService.findById(id);
    if (!doc) return res.status(404).json({ message: 'Servicio no encontrado' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /servicios
async function create(req, res) {
  try {
    const doc = await ServiciosService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /servicios/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await ServiciosService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Servicio no encontrado' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /servicios/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await ServiciosService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Servicio no encontrado' });
    res.json({ message: 'Servicio eliminado correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove };
