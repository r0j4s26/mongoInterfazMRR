const mongoose = require('mongoose');
const EmpleadosService = require('../services/empleadosService');

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /empleados
async function getAll(req, res) {
  try {
    const { page = 1, limit = 50, cedula, email, puesto, q } = req.query;

    const filter = {};
    if (cedula) filter.cedula = Number(cedula);
    if (email) filter.email = email;
    if (puesto) filter.puesto = puesto;
    if (q) filter.nombre = { $regex: q, $options: 'i' };

    const options = {
      sort: { nombre: 1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await EmpleadosService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /empleados/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await EmpleadosService.findById(id);
    if (!doc) return res.status(404).json({ message: 'Empleado no encontrado' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /empleados
async function create(req, res) {
  try {
    const doc = await EmpleadosService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /empleados/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await EmpleadosService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Empleado no encontrado' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /empleados/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await EmpleadosService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Empleado no encontrado' });
    res.json({ message: 'Empleado eliminado correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove };
