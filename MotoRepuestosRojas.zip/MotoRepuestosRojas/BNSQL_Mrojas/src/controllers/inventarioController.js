const mongoose = require('mongoose');
const InventarioService = require('../services/inventarioService');

const VALID_INCLUDES = {
  producto: { path: 'productoId' }
};

function buildPopulate(includeParam) {
  if (!includeParam) return undefined;
  const parts = String(includeParam).split(',').map(s => s.trim()).filter(Boolean);
  const populate = parts.map(p => VALID_INCLUDES[p]).filter(Boolean);
  return populate.length ? populate : undefined;
}

function isValidObjectId(id) {
  return mongoose.Types.ObjectId.isValid(id);
}

// GET /inventario
async function getAll(req, res) {
  try {
    const { include, page = 1, limit = 50, productoId, agotado, bajoStock } = req.query;

    const filter = {};
    if (productoId && isValidObjectId(productoId)) filter.productoId = productoId;

    // Filtros de stock
    // agotado=true -> cantidadDisponible <= 0
    if (String(agotado).toLowerCase() === 'true') {
      filter.cantidadDisponible = { $lte: 0 };
    }
    // bajoStock=true -> cantidadDisponible <= stockMinimo (si no se definió "agotado")
    if (String(bajoStock).toLowerCase() === 'true' && !filter.cantidadDisponible) {
      filter.$expr = { $lte: ['$cantidadDisponible', '$stockMinimo'] };
    }

    const options = {
      populate: buildPopulate(include),
      sort: { fechaCompra: -1 },
      limit: Math.min(Number(limit) || 50, 200),
      skip: (Math.max(Number(page) || 1, 1) - 1) * (Number(limit) || 50)
    };

    const docs = await InventarioService.findAll(filter, options);
    res.json(docs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// GET /inventario/:id
async function getOne(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await InventarioService.findById(id, { populate: buildPopulate(req.query.include) });
    if (!doc) return res.status(404).json({ message: 'Inventario no encontrado' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// POST /inventario
async function create(req, res) {
  try {
    const doc = await InventarioService.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// PUT /inventario/:id
async function update(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await InventarioService.updateById(id, req.body);
    if (!doc) return res.status(404).json({ message: 'Inventario no encontrado' });
    res.json(doc);
  } catch (err) {
    const status = err.name === 'ValidationError' ? 400 : 500;
    res.status(status).json({ message: err.message });
  }
}

// DELETE /inventario/:id
async function remove(req, res) {
  try {
    const { id } = req.params;
    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });

    const doc = await InventarioService.deleteById(id);
    if (!doc) return res.status(404).json({ message: 'Inventario no encontrado' });
    res.json({ message: 'Inventario eliminado correctamente' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

// PATCH /inventario/:id/ajustar  { "delta": -3 }  // suma/resta stock
async function ajustar(req, res) {
  try {
    const { id } = req.params;
    const { delta } = req.body;

    if (!isValidObjectId(id)) return res.status(400).json({ message: 'ID inválido' });
    if (typeof delta !== 'number' || Number.isNaN(delta)) {
      return res.status(400).json({ message: 'delta debe ser un número' });
    }

    const doc = await InventarioService.ajustarStock(id, delta);
    if (!doc) return res.status(404).json({ message: 'Inventario no encontrado' });

    // (Opcional) Evitar negativos: si quedó < 0, lo llevamos a 0
    if (doc.cantidadDisponible < 0) {
      const fixed = await InventarioService.updateById(id, { cantidadDisponible: 0 });
      return res.json(fixed);
    }

    res.json(doc);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports = { getAll, getOne, create, update, remove, ajustar };
