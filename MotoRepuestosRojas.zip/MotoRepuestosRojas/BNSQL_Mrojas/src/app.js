require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./config/db');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());

// Rutas
app.use('/productos', require('./routes/productoRoutes'));
app.use('/proveedores', require('./routes/proveedoresRoutes'));
app.use('/citas', require('./routes/citasRoutes'));
app.use('/clientes', require('./routes/clientesRoutes'));
app.use('/compras', require('./routes/comprasRoutes'));
app.use('/empleados', require('./routes/empleadosRoutes'));
app.use('/encargos', require('./routes/encargosRoutes'));
app.use('/facturas', require('./routes/facturasRoutes'));
app.use('/historialdepago', require('./routes/historialDePagoRoutes')); 
app.use('/inventario', require('./routes/inventarioRoutes'));
app.use('/motos', require('./routes/motosRoutes'));
app.use('/servicios', require('./routes/serviciosRoutes'));

// Conexión a la base de datos y arranque del servidor
connectDB()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Servidor corriendo en http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Error conectando a MongoDB:', err);
    process.exit(1);
  });
