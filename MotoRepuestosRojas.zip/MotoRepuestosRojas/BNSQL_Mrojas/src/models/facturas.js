const mongoose = require('mongoose');
const facturasSchema = new mongoose.Schema({
  
  compraId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Compras', 
    required: true
  },
  numeroFactura: { type: Number, required: true },
  fecha: { type: Date, default: Date.now, required: true },
  montoTotal: { type: Number, required: true, min: 0 },
  estadoPago: { 
    type: String, 
    enum: ['pagada', 'pendiente', 'vencida'], 
    default: 'pendiente' 
  }
}, { collection: 'Facturas' });
 
module.exports = mongoose.model('Factura', facturasSchema);
