const mongoose = require('mongoose');

const historialDePagoSchema = new mongoose.Schema({
  clienteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Clientes' },
  fechaPago: { type: Date, default: Date.now },
  monto: { type: Number },
  descripcion:{ type: String },
  metodoPago: { 
    type: String, 
    enum: ['efectivo', 'tarjeta', 'transferencia', 'otro'] 
  }
}, { collection: 'HistorialDePago' });

module.exports = mongoose.model('HistorialDePago', historialDePagoSchema);
