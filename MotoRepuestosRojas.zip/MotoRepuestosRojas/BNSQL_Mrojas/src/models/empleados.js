const mongoose = require('mongoose');

const empleadosSchema = new mongoose.Schema({
  nombre: { type: String },
  cedula: { type: Number },
  puesto: { type: String },
  telefono: { type: Number },
  email: { type: String },
  direccion: { type: String },
  fechaContratacion: { type: Date, default: Date.now },
  salario: { type: Number }
}, { collection: 'Empleados' });

module.exports = mongoose.model('Empleados', empleadosSchema);
