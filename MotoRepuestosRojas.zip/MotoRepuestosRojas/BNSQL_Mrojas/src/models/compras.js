const mongoose = require('mongoose');

const comprasSchema = new mongoose.Schema({
  proveedorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Proveedores' },
  fechaCompra: { type: Date, default: Date.now },
  productosComprados: { type: Array },
  totalCompra: { type: Number },
  estado: { 
    type: String, 
    enum: ['pendiente', 'completada', 'cancelada'], 
    default: 'pendiente' 
  }
}, { collection: 'Compras' });

module.exports = mongoose.model('Compras', comprasSchema);
