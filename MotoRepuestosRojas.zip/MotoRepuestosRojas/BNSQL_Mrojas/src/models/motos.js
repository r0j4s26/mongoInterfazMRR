const mongoose = require('mongoose');

const motosSchema = new mongoose.Schema({
  clienteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Clientes' },
  marca: { type: String },
  modelo: { type: String },
  placa: { type: Number },
  anio: { type: Number }
}, { collection: 'Motos' });

module.exports = mongoose.model('Motos', motosSchema);
