const mongoose = require('mongoose');

const clientesSchema = new mongoose.Schema({
  nombre:   { type: String },
  cedula:   { type: String },
  telefono: { type: String },
  email:    { type: String },
  direccion:{ type: String },
  motos:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'Motos' }]
}, { collection: 'Clientes' });

module.exports = mongoose.model('Clientes', clientesSchema);
