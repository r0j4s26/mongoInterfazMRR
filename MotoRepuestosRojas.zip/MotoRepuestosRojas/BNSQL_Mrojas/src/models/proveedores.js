const mongoose = require('mongoose');

const proveedoresSchema = new mongoose.Schema({
    nombre: { type: String, required: true },
    telefono: { type: Number },
    email: { type: String },
    direccion: { type: String }
}, { collection: 'Proveedores' });

module.exports = mongoose.model('Proveedor', proveedoresSchema);
