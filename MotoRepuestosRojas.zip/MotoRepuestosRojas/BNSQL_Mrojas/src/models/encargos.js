const mongoose = require('mongoose');

const encargosSchema = new mongoose.Schema({
  clienteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Clientes' },
  productoNombre: { type: String },
  fechaEncargo: { type: Date, default: Date.now },
  estado: { 
    type: String, 
    enum: ['pendiente', 'en proceso', 'completado', 'entregado', 'cancelado'], 
    default: 'pendiente' 
  },
  precioEstimado:  { type: Number }
}, { collection: 'Encargos' });

module.exports = mongoose.model('Encargos', encargosSchema);
