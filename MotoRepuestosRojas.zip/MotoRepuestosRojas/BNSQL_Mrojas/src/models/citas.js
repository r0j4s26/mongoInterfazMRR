const mongoose = require('mongoose');

const citasSchema = new mongoose.Schema({
  clienteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Cliente', required: true },
  motoId: { type: mongoose.Schema.Types.ObjectId, ref: 'Moto', required: true },
  servicioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Servicio', required: true },
  fechaCita: { type: Date, required: true },
  motivo: { type: String },
  estado: { 
    type: String, 
    enum: ['pendiente', 'confirmada', 'cancelada', 'completada'], 
    default: 'pendiente' 
  },
  empleadoAsignadoId: { type: mongoose.Schema.Types.ObjectId, ref: 'Empleado' }
}, { collection: 'Citas', timestamps: true });

module.exports = mongoose.model('Citas', citasSchema);
