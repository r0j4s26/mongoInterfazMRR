const mongoose = require('mongoose');

const serviciosSchema = new mongoose.Schema({

    nombre: {type: String},
    descripcion: {type: String},
    precio: {type: Number}
    
}, { collection: 'Servicios'});

module.exports = mongoose.model('Servicios', serviciosSchema);