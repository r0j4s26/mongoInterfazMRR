const mongoose = require('mongoose');
 
const productoSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  descripcion: { type: String },
  marca: { type: String },
  modelo: { type: String },
  precio_venta: { type: Number, required: true, min: 0.01 },
  costo_compra: { type: Number, required: true, min: 0 },
  cantidad_disponible: { type: Number, required: true, min: 0, default: 0 },
  categoria: { type: String },
  imagenUrl: { type: String }
}, { collection: 'Productos' });
 
module.exports = mongoose.model('Producto', productoSchema);