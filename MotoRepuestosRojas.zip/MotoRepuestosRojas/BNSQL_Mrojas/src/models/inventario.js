const mongoose = require('mongoose');
const inventarioSchema = new mongoose.Schema({

  productoId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Producto',
    required: true
  },
  cantidad: {
    type: Number,
    required: true,
    min: 0
  },
  fechaCompra: {
    type: Date,
    default: Date.now
  },
  stockMinimo: {
    type: Number,
    min: 0,
    default: 0
  }
}, { collection: 'Inventario' });
 
module.exports = mongoose.model('Inventario', inventarioSchema);
