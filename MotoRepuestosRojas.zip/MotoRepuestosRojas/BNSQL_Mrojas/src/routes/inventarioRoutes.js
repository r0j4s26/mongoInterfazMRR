const express = require('express');
const router = express.Router();
const controller = require('../controllers/inventarioController');

router.get('/', controller.getAll);
router.get('/:id', controller.getOne);
router.post('/', controller.create);
router.put('/:id', controller.update);
router.delete('/:id', controller.remove);

// Ajuste de stock (sumar/restar)
router.patch('/:id/ajustar', controller.ajustar);

module.exports = router;
