const express = require('express');
const router = express.Router();
const controller = require('../controllers/facturasController');

router.get('/', controller.getAll);
router.get('/:id', controller.getOne);
router.post('/', controller.create);
router.put('/:id', controller.update);
router.delete('/:id', controller.remove);
// router.get('/con-clientes', controller.getAllWithClientes);

module.exports = router;
