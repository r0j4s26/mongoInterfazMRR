const Motos = require('../models/motos');

class MotosService {
  async create(data) {
    const doc = new Motos(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Motos.find(filter);
    if (options.populate) query.populate(options.populate);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id, options = {}) {
    let query = Motos.findById(id);
    if (options.populate) query = query.populate(options.populate);
    return query.exec();
  }

  async updateById(id, data, options = {}) {
    return Motos.findByIdAndUpdate(id, data, { new: true, ...options }).exec();
  }

  async deleteById(id) {
    return Motos.findByIdAndDelete(id).exec();
  }
}

module.exports = new MotosService();
