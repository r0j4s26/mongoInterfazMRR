const Producto = require('../models/producto');

class ProductoService {
  async create(data) {
    const doc = new Producto(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Producto.find(filter);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id) {
    return Producto.findById(id).exec();
  }

  async updateById(id, data) {
    return Producto.findByIdAndUpdate(id, data, { new: true }).exec();
  }

  async deleteById(id) {
    return Producto.findByIdAndDelete(id).exec();
  }
}

module.exports = new ProductoService();
