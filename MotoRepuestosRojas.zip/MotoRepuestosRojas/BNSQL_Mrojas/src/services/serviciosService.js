const Servicios = require('../models/servicios');

class ServiciosService {
  async create(data) {
    const doc = new Servicios(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Servicios.find(filter);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id) {
    return Servicios.findById(id).exec();
  }

  async updateById(id, data) {
    return Servicios.findByIdAndUpdate(id, data, { new: true }).exec();
  }

  async deleteById(id) {
    return Servicios.findByIdAndDelete(id).exec();
  }
}

module.exports = new ServiciosService();
