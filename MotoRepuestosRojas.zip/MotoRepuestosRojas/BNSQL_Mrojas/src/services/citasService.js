const Citas = require('../models/citas');

class CitasService {
  async create(data) {
    const doc = new Citas(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Citas.find(filter);
    if (options.populate) query.populate(options.populate);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id, options = {}) {
    let query = Citas.findById(id);
    if (options.populate) query = query.populate(options.populate);
    return query.exec();
  }

  async updateById(id, data, options = {}) {
    return Citas.findByIdAndUpdate(id, data, { new: true, ...options }).exec();
  }

  async deleteById(id) {
    return Citas.findByIdAndDelete(id).exec();
  }
}

module.exports = new CitasService();
