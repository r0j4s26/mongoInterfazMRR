const Inventario = require('../models/inventario');

class InventarioService {
  async create(data) {
    const doc = new Inventario(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Inventario.find(filter);
    if (options.populate) query.populate(options.populate);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id, options = {}) {
    let query = Inventario.findById(id);
    if (options.populate) query = query.populate(options.populate);
    return query.exec();
  }

  async updateById(id, data, options = {}) {
    return Inventario.findByIdAndUpdate(id, data, { new: true, ...options }).exec();
  }

  async deleteById(id) {
    return Inventario.findByIdAndDelete(id).exec();
  }

  // Ajuste de stock usando $inc
  async ajustarStock(id, delta) {
    return Inventario.findByIdAndUpdate(
      id,
      { $inc: { cantidadDisponible: delta } },
      { new: true }
    ).exec();
  }
}

module.exports = new InventarioService();
