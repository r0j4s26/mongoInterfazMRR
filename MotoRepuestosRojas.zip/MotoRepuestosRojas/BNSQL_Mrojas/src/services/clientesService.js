const Clientes = require('../models/clientes');

class ClientesService {
  async create(data) {
    const doc = new Clientes(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Clientes.find(filter);
    if (options.populate) query.populate(options.populate);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id, options = {}) {
    let query = Clientes.findById(id);
    if (options.populate) query = query.populate(options.populate);
    return query.exec();
  }

  async updateById(id, data, options = {}) {
    return Clientes.findByIdAndUpdate(id, data, { new: true, ...options }).exec();
  }

  async deleteById(id) {
    return Clientes.findByIdAndDelete(id).exec();
  }
}

module.exports = new ClientesService();
