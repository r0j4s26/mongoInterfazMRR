const Encargos = require('../models/encargos');

class EncargosService {
  async create(data) {
    const doc = new Encargos(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Encargos.find(filter);
    if (options.populate) query.populate(options.populate);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id, options = {}) {
    let query = Encargos.findById(id);
    if (options.populate) query = query.populate(options.populate);
    return query.exec();
  }

  async updateById(id, data, options = {}) {
    return Encargos.findByIdAndUpdate(id, data, { new: true, ...options }).exec();
  }

  async deleteById(id) {
    return Encargos.findByIdAndDelete(id).exec();
  }
}

module.exports = new EncargosService();
