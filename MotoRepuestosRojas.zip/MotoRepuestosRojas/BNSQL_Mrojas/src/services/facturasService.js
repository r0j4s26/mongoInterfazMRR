const Facturas = require('../models/facturas');

class FacturasService {
  async create(data) {
    const doc = new Facturas(data);
    await doc.save();
    return doc;
  }

  async findAll(filter = {}, options = {}) {
    const query = Facturas.find(filter);
    if (options.populate) query.populate(options.populate);
    if (options.sort) query.sort(options.sort);
    if (options.limit) query.limit(options.limit);
    if (options.skip) query.skip(options.skip);
    return query.exec();
  }

  async findById(id, options = {}) {
    let query = Facturas.findById(id);
    if (options.populate) query = query.populate(options.populate);
    return query.exec();
  }

  async updateById(id, data, options = {}) {
    return Facturas.findByIdAndUpdate(id, data, { new: true, ...options }).exec();
  }

  async deleteById(id) {
    return Facturas.findByIdAndDelete(id).exec();
  }

//   async findAllWithClientes() {
//     return Facturas.aggregate([
//     {
//       $lookup: {
//         from: "Clientes",
//         localField: "id_cliente",
//         foreignField: "_id",
//         as: "datos_del_cliente"
//       }
//     }
//   ]);
// }
}

module.exports = new FacturasService();
